class Product{
    constructor(id,pname,price,img,amount=1){
        this.id = id
        this.pname = pname
        this.price = price
        this.img = img
        this.amount = amount
    }
}
export default Product