<template>
    <div id="cart">
        <h1>cart</h1>
    </div>
</template>
<script>
</script>
<style>
#cart{}
</style>