<template>
  <div id="home">
    <h1>Home</h1>
  </div>
</template>
<script>
   export default {
    name: 'HomeCompo',
    props: {
  }
}
</script>
<style>
#home{
  
}
</style>